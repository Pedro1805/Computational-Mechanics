
%Cálculo B

function [B,DetJ] = B_Q4 (x1,y1,x2,y2,x3,y3,x4,y4,csi,eta)
pontos = zeros(4,2);
pontos = [x1 y1; x2 y2; x3 y3; x4 y4];

Dpsi = zeros(4,2);

%Derivadas parciais das funções de forma em ordem a csi
Dpsi(1,1) = (eta-1)/4;
Dpsi(2,1) = (1-eta)/4;
Dpsi(3,1) = (1+eta)/4;
Dpsi(4,1) = -(1+eta)/4;

%Derivadas parciais das funções de forma em ordem a eta
Dpsi(1,2) = (csi-1)/4;
Dpsi(2,2) = -(csi+1)/4;
Dpsi(3,2) = (1+csi)/4;
Dpsi(4,2) = (1-csi)/4;

J = pontos'*Dpsi; % (2x2) = (2x4)*(4x2)
DetJ = det(J); 

B1 = Dpsi*inv(J);

B = [B1(1,1) 0 B1(2,1) 0 B1(3,1) 0 B1(4,1) 0;
   0 B1(1,2) 0 B1(2,2) 0 B1(3,2) 0 B1(4,2);
   B1(1,2) B1(1,1) B1(2,2) B1(2,1) B1(3,2) B1(3,1) B1(4,2) B1(4,1)];
end

