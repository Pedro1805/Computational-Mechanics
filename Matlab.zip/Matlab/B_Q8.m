
function [B, DetJ] = B_Q8(x1,y1,x2,y2,x3,y3,x4,y4,x5,y5,x6,y6,x7,y7,x8,y8,csi,eta)

pontos = zeros(8,2);
pontos = [x1 y1; x2 y2; x3 y3; x4 y4; x5 y5; x6 y6; x7 y7; x8 y8];

Dpsi = zeros(8,2);

%Derivadas parciais das funções de forma em ordem a csi
Dpsi(1,1) = (2*csi+eta)*(1-eta)/4;
Dpsi(2,1) = (2*csi-eta)*(1-eta)/4;
Dpsi(3,1) = (2*csi+eta)*(1+eta)/4;
Dpsi(4,1) = (2*csi-eta)*(1+eta)/4;
Dpsi(5,1) = csi*(eta-1);
Dpsi(6,1) = (1-eta*eta)/2;
Dpsi(7,1) = -csi*(1+eta);
Dpsi(8,1) = (eta*eta-1)/2;

%Derivadas parciais das funções de forma em ordem a eta
Dpsi(1,2) = (2*eta+csi)*(1-csi)/4;
Dpsi(2,2) = (2*eta-csi)*(1+csi)/4;
Dpsi(3,2) = (2*eta+csi)*(1+csi)/4;
Dpsi(4,2) = (2*eta-csi)*(1-csi)/4;
Dpsi(5,2) = (csi*csi-1)/2;
Dpsi(6,2) = -(1+csi)*eta;
Dpsi(7,2) = (1-csi*csi)/2;
Dpsi(8,2) = (csi-1)*eta;

J = pontos'*Dpsi; 
DetJ = det(J);

B1 = Dpsi*inv(J);

B = [B1(1,1) 0 B1(2,1) 0 B1(3,1) 0 B1(4,1) 0 B1(5,1) 0 B1(6,1) 0 B1(7,1) 0 B1(8,1) 0;
   0 B1(1,2) 0 B1(2,2) 0 B1(3,2) 0 B1(4,2) 0 B1(5,2) 0 B1(6,2) 0 B1(7,2) 0 B1(8,2);
   B1(1,2) B1(1,1) B1(2,2) B1(2,1) B1(3,2) B1(3,1) B1(4,2) B1(4,1) B1(5,2) B1(5,1) B1(6,2) B1(6,1) B1(7,2) B1(7,1) B1(8,2) B1(8,1)];
end
