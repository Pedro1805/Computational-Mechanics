

function [B, DetJ] = B_T6(x1,y1,x2,y2,x3,y3,x4,y4,x5,y5,x6,y6,csi,eta)

pontos = zeros(6,2);
pontos = [x1 y1; x2 y2; x3 y3; x4 y4; x5 y5; x6 y6];

Dpsi = zeros(6,2);

%Derivadas parciais das funções de forma em ordem a csi
Dpsi(1,1) = 4*(csi+eta)-3;
Dpsi(2,1) = 4*csi-1;
Dpsi(3,1) = 0;
Dpsi(4,1) = 4*(1-eta-2*csi);
Dpsi(5,1) = 4*eta;
Dpsi(6,1) = -4*eta;

%Derivadas parciais das funções de forma em ordem a eta
Dpsi(1,2) = Dpsi(1,1);
Dpsi(2,2) = 0;
Dpsi(3,2) = 4*eta-1;
Dpsi(4,2) = -4*csi;
Dpsi(5,2) = 4*csi;
Dpsi(6,2) = 4*(1-2*eta-csi);

J = pontos'*Dpsi; 
DetJ = det(J); 
B1 = Dpsi*inv(J);

B = [B1(1,1) 0 B1(2,1) 0 B1(3,1) 0 B1(4,1) 0 B1(5,1) 0 B1(6,1) 0;
   0 B1(1,2) 0 B1(2,2) 0 B1(3,2) 0 B1(4,2) 0 B1(5,2) 0 B1(6,2);
   B1(1,2) B1(1,1) B1(2,2) B1(2,1) B1(3,2) B1(3,1) B1(4,2) B1(4,1) B1(5,2) B1(5,1) B1(6,2) B1(6,1)];

end



