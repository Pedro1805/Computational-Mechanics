
%Utiliza todas as funções necessárias ao desenvolvimento do programa para a
%realização dos gráficos

function Colocar(Ficheiro,NNOE)
[NTN,MatrizNOs,NTE,MatrizConectividades,E,...
    V,T,MatrizCondFronteira,MatrizTensFronteira] = LeituraDados(Ficheiro,NNOE);

Constante = E/((1+V)*(1-2*V));
C = Constante*[1-V V 0; V 1-V 0; 0 0 0.5*(1-2*V)];

if NNOE == 4
    [MatrizNOs, MatrizConectividades,u,v,Tensaox,Extensaox,Tensaoy,Extensaoy,Tensaoxy,...
    Extensaoxy,Extensaoz,VonMises,NTE,x,y,E_def,V] = Q4(Ficheiro,NNOE);

elseif NNOE == 8
    [MatrizNOs, MatrizConectividades,u,v,Tensaox,Extensaox,Tensaoy,Extensaoy,Tensaoxy,...
    Extensaoxy,Extensaoz,VonMises,NTE,x,y,E_def,V] = Q8(Ficheiro,NNOE);

elseif NNOE == 3
    [MatrizNOs, MatrizConectividades,u,v,Tensaox,Extensaox,Tensaoy,Extensaoy,Tensaoxy,...
    Extensaoxy,Extensaoz,VonMises,NTE,x,y,E_def,V] = T3(Ficheiro,NNOE);

elseif NNOE == 6
    [MatrizNOs, MatrizConectividades,u,v,Tensaox,Extensaox,Tensaoy,Extensaoy,Tensaoxy,...
    Extensaoxy,Extensaoz,VonMises,NTE,x,y,E_def,V] = T6(Ficheiro,NNOE);

end

[TensaoxMax,TensaoxMin,TensaoyMax,TensaoyMin,TensaoxyMax,...
    TensaoxyMin,ExtensaoxMax,ExtensaoxMin,ExtensaoyMax,ExtensaoyMin,ExtensaoxyMax,...
    ExtensaoxyMin,ExtensaozMax,ExtensaozMin,uMax,uMin,vMax,vMin,VonMisesMax,VonMisesMin] = Maximos_e_Minimos(Tensaox,Tensaoy,...
    Tensaoxy,Extensaox,Extensaoy,Extensaoxy,Extensaoz,u,v,VonMises);

[TensorTensoes,Tensoes_Principais] = Tensor_Tensoes(Tensaox,Tensaoy,Tensaoxy,NTE);

GuardarValores(NTN,NNOE,MatrizNOs,NTE,MatrizConectividades,E,...
    V,T,C,MatrizCondFronteira,MatrizTensFronteira,u,v,VonMises,E_def,...
    Tensaox,Extensaox,Tensaoy,Extensaoy,Tensaoxy,Extensaoxy,Extensaoz,x,y,TensaoxMax,TensaoxMin,...
    TensaoyMax,TensaoyMin,TensaoxyMax,TensaoxyMin,ExtensaoxMax,ExtensaoxMin,ExtensaoyMax,ExtensaoyMin,...
    ExtensaoxyMax,ExtensaoxyMin,ExtensaozMax,ExtensaozMin,uMax,uMin,vMax,vMin,VonMisesMax,VonMisesMin,TensorTensoes,Tensoes_Principais)

end
