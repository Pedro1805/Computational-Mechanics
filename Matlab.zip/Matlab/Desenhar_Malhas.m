%Faz o gráfico das malhas, de acordo com o tipo de malha escolhido

function Desenhar_Malhas(Malha,NNOE,NTE,NTN,MatrizNOs,MatrizConectividades)

u = evalin('base','u');
v = evalin('base','v');
Tensaox = evalin('base','Tensaox');
Tensaoy = evalin('base','Tensaoy');
Tensaoxy = evalin('base','Tensaoxy');
Extensaox = evalin('base','Extensaox');
Extensaoy = evalin('base','Extensaoy');
Extensaoxy = evalin('base','Extensaoxy');
Extensaoz = evalin('base','Extensaoz');
VonMises = evalin('base','VonMises');

xDeformada = MatrizNOs(:,2)+ u(:);
yDeformada = MatrizNOs(:,3)+ v(:);
MatrizNOsDeformada = [MatrizNOs(:,1) xDeformada yDeformada];

if Malha == 1
    figure('Position',[300 100 900 500]);
    Malhas(1,1,NNOE,NTE,NTN,MatrizNOsDeformada,MatrizConectividades);
    axis([(min(MatrizNOsDeformada(:,2))-10) (max(MatrizNOsDeformada(:,2))+10) (min(MatrizNOsDeformada(:,3))-10) (max(MatrizNOsDeformada(:,3))+10)]);
    title('Malha');

elseif Malha == 2
    figure('Position',[50 175 1200 300])
    subplot(1,2,1)
    Malhas(2,abs(u(:,1)),NNOE,NTE,NTN,MatrizNOsDeformada,MatrizConectividades);
    title('Deslocamento em x');
    subplot(1,2,2)
    Malhas(2,abs(v(:,1)),NNOE,NTE,NTN,MatrizNOsDeformada,MatrizConectividades);
    title('Deslocamento em y');    
    sgtitle('Deslocamentos','fontsize',14);
    
elseif Malha == 3
    figure('Position',[100 25 1100 600])
    subplot(2,2,1)
    Malhas(2,Tensaox,NNOE,NTE,NTN,MatrizNOsDeformada,MatrizConectividades);
    title('Tensão X');
    subplot(2,2,2)
    Malhas(2,Tensaoy,NNOE,NTE,NTN,MatrizNOsDeformada,MatrizConectividades);
    title('Tensão Y');
    subplot(2,2,3.5)
    Malhas(2,Tensaoxy,NNOE,NTE,NTN,MatrizNOsDeformada,MatrizConectividades);
    title('Tensão XY');
    sgtitle('Tensões','fontsize',14);
    
elseif Malha == 4
    figure('Position',[100 25 1100 600])
    subplot(2,2,1)
    Malhas(2,Extensaox,NNOE,NTE,NTN,MatrizNOsDeformada,MatrizConectividades);
    title('Extensão X');
    subplot(2,2,2)
    Malhas(2,Extensaoy,NNOE,NTE,NTN,MatrizNOsDeformada,MatrizConectividades);
    title('Extensão Y');
    subplot(2,2,3)
    Malhas(2,Extensaoxy,NNOE,NTE,NTN,MatrizNOsDeformada,MatrizConectividades);
    title('Extensão XY');
    subplot(2,2,4)
    Malhas(2,Extensaoz,NNOE,NTE,NTN,MatrizNOsDeformada,MatrizConectividades);
    title('Extensão Z');
    sgtitle('Extensões','fontsize',14)
    
elseif Malha == 5
    figure('Position',[200 100 900 500])
    Malhas(2,VonMises(:,2),NNOE,NTE,NTN,MatrizNOsDeformada,MatrizConectividades);
    title('Tensão Von Mises');

end

    

    

