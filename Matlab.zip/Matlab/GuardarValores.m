%Guarda valores calculados na workspace

function GuardarValores(NTN,NNOE,MatrizNOs,NTE,MatrizConectividades,E,...
    V,T,C,MatrizCondFronteira,MatrizTensFronteira,u,v,VonMises,E_def,...
    Tensaox,Extensaox,Tensaoy,Extensaoy,Tensaoxy,Extensaoxy,Extensaoz,x,y,TensaoxMax,TensaoxMin,...
    TensaoyMax,TensaoyMin,TensaoxyMax,TensaoxyMin,ExtensaoxMax,ExtensaoxMin,ExtensaoyMax,ExtensaoyMin,...
    ExtensaoxyMax,ExtensaoxyMin,ExtensaozMax,ExtensaozMin,uMax,uMin,vMax,vMin,VonMisesMax,VonMisesMin,TensorTensoes,Tensoes_Principais)

assignin('base','NTN',NTN);
assignin('base','NNOE',NNOE);
assignin('base','x',x);
assignin('base','y',y);
assignin('base','MatrizNOs',MatrizNOs);
assignin('base','NTE',NTE);
assignin('base','MatrizConectividades',MatrizConectividades)
assignin('base','E',E);
assignin('base','V',V);
assignin('base','T',T);
assignin('base','C',C);
assignin('base','MatrizCondFronteira',MatrizCondFronteira);
assignin('base','MatrizTensFronteira',MatrizTensFronteira);
assignin('base','u',u);
assignin('base','v',v);
assignin('base','Tensaox',Tensaox);
assignin('base','Tensaoy',Tensaoy);
assignin('base','Tensaoxy',Tensaoxy);
assignin('base','Extensaox',Extensaox);
assignin('base','Extensaoy',Extensaoy);
assignin('base','Extensaoxy',Extensaoxy);
assignin('base','Extensaoz',Extensaoz');
assignin('base','VonMises',VonMises);

assignin('base','uMax',uMax);
assignin('base','uMin',uMin);
assignin('base','vMax',vMax);
assignin('base','vMin',vMin);

assignin('base','TensaoxMax',TensaoxMax);
assignin('base','TensaoxMin',TensaoxMin);
assignin('base','TensaoyMax',TensaoyMax);
assignin('base','TensaoyMin',TensaoyMin);
assignin('base','TensaoxyMax',TensaoxyMax);
assignin('base','TensaoxyMin',TensaoxyMin);
assignin('base','ExtensaoxMax',ExtensaoxMax);
assignin('base','ExtensaoxMin',ExtensaoxMin);
assignin('base','ExtensaoyMax',ExtensaoyMax);
assignin('base','ExtensaoyMin',ExtensaoyMin);
assignin('base','ExtensaoxyMax',ExtensaoxyMax);
assignin('base','ExtensaoxyMin',ExtensaoxyMin);
assignin('base','ExtensaozMax',ExtensaozMax');
assignin('base','ExtensaozMin',ExtensaozMin');
assignin('base','VonMisesMax',VonMisesMax');
assignin('base','VonMisesMin',VonMisesMin');

assignin('base','TensorTensoes',TensorTensoes);
assignin('base','Tensoes_Principais',Tensoes_Principais);

assignin('base','E_def',E_def);

end
