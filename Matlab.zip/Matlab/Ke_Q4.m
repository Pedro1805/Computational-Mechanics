%Calculo Ke 

function [Ke,fe] = Ke_Q4(x1,y1,x2,y2,x3,y3,x4,y4,C,T)

%Gauss-Legendre (2D)
G = sqrt(1/3);
xp = [-G G -G G;-G -G G G]' ;
wp = [1 1 1 1]';

Ke = zeros(8,8);
fe = zeros(8,1);

for ip = 1:4
    csi = xp(ip,1);
    eta = xp(ip,2);
    [B, DetJ] = B_Q4(x1,y1,x2,y2,x3,y3,x4,y4,csi,eta);

    wip = T*wp(ip)*DetJ;
    Ke = Ke + wip*B'*C*B;
end

end


