%Calculo Ke

function [Ke, fe] = Ke_Q8(x1,y1,x2,y2,x3,y3,x4,y4,x5,y5,x6,y6,x7,y7,x8,y8,C,T)

G = sqrt(0.6);
xp = [-G 0 G -G 0 G -G 0 G;-G -G -G 0 0 0 G G G]';
wp = [25 40 25 40 64 40 25 40 25]'/81;

Ke = zeros(16,16);
fe = zeros(16,1);

for ip=1:8
    
    csi = xp(ip,1);
    eta = xp(ip,2);
    [B, DetJ] = B_Q8(x1,y1,x2,y2,x3,y3,x4,y4,x5,y5,x6,y6,x7,y7,x8,y8,csi,eta);
    
    wip = T*wp(ip)*DetJ;
    Ke = Ke + wip*B'*C*B;
end