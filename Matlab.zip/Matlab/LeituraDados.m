%Extrai os dados provenientes da simulação em Siemens NX para um ficheiro excel e depois para um ficheiro de texto

function [NTN,MatrizNOs,NTE,MatrizConectividades,E,...
    V,T,MatrizCondFronteira,MatrizTensFronteira] = LeituraDados(Ficheiro,NNOE)

Dados = fopen(Ficheiro,'r');

%Coordenadas dos nós
Titulo = fgetl(Dados); % Lê e ignora a linha lida do ficheiro
Titulo1 = fgetl(Dados); % Lê e ignora a linha lida do ficheiro
NTN = str2double(fgetl(Dados)); %converte a próxima linha não lida de string para numérica
MatrizNOs = fscanf(Dados,'%f',[3 NTN]);
MatrizNOs = MatrizNOs';

%Matriz das Conectividades
Titulo2 = fgetl(Dados);
Titulo3 = fgetl(Dados);
NTE = str2num(fgetl(Dados));
MatrizConectividades = fscanf(Dados,'%f',[NNOE+3 inf]); %NNOE - número de nós por elemento
MatrizConectividades = MatrizConectividades';

%Propriedades do Material
Titulo4 = fgetl(Dados);
NTM = str2double(fgetl(Dados));
MatrizPropriedades = fscanf(Dados,'%f', [5 inf]);
MatrizPropriedades = MatrizPropriedades';
E = MatrizPropriedades(1,3);
V = MatrizPropriedades(1,4);
T = MatrizPropriedades(1,5); %espessura

%Carregamentos Distribuídos
Titulo5 = fgetl(Dados);
NTECD = str2double(fgetl(Dados));

%Condição fronteira essencial
Titulo6 = fgetl(Dados);
NTGLI = str2double(fgetl(Dados));
MatrizCondFronteira = fscanf(Dados,'%f', [3 inf]);
MatrizCondFronteira = MatrizCondFronteira';

%Cargas Pontuais
Titulo7 = fgetl(Dados);
NTCPI = str2double(fgetl(Dados));

%Tensão na fronteira
Titulo7 = fgetl(Dados);
NTEFI = str2double(fgetl(Dados));

if NNOE == 3 || NNOE == 4
    MatrizTensFronteira = fscanf(Dados,'%f', [5 inf]);
else 
    MatrizTensFronteira = fscanf(Dados,'%f', [6 inf]); 
end
MatrizTensFronteira = MatrizTensFronteira';

fclose(Dados);


end
