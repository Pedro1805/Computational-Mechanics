

function Malhas(escolher,analise,NNOE,NTE,NTN,MatrizNOs,MatrizConectividades)

X = zeros(NNOE,NTE);
Y = zeros(NNOE,NTE);
analisar = zeros(NNOE,NTE);
MatrizConectividadesReordenada = zeros(NTE,NNOE);
assignin('base','X',X);
assignin('base','Y',Y);

for i=1:NTE
    
    if NNOE == 6    % Elementos triangulares quadráticos
        MatrizConectividadesReordenada(i,4) = MatrizConectividades(i,4);
        MatrizConectividadesReordenada(i,5) = MatrizConectividades(i,7);
        MatrizConectividadesReordenada(i,6) = MatrizConectividades(i,5);
        MatrizConectividadesReordenada(i,7) = MatrizConectividades(i,8);
        MatrizConectividadesReordenada(i,8) = MatrizConectividades(i,6);
        MatrizConectividadesReordenada(i,9) = MatrizConectividades(i,9);
        
    elseif NNOE == 8  % Elementos quadrangulares quadráticos
        MatrizConectividadesReordenada(i,4) = MatrizConectividades(i,4);
        MatrizConectividadesReordenada(i,5) = MatrizConectividades(i,8);
        MatrizConectividadesReordenada(i,6) = MatrizConectividades(i,5);
        MatrizConectividadesReordenada(i,7) = MatrizConectividades(i,9);
        MatrizConectividadesReordenada(i,8) = MatrizConectividades(i,6);
        MatrizConectividadesReordenada(i,9) = MatrizConectividades(i,10);
        MatrizConectividadesReordenada(i,10) = MatrizConectividades(i,7);
        MatrizConectividadesReordenada(i,11) = MatrizConectividades(i,11);
         
    else %Elementos Lineares (não é necessário reordenar)
        MatrizConectividadesReordenada = MatrizConectividades;
    end

    X(1:NNOE,i) = MatrizNOs(MatrizConectividadesReordenada(i,4:NNOE+3),2);
    Y(1:NNOE,i) = MatrizNOs(MatrizConectividadesReordenada(i,4:NNOE+3),3);
   
    if length(analise) == NTN     
        analisar(:,i) = analise(MatrizConectividadesReordenada(i,4:NNOE+3)');
    else     
        analisar = analise;
    end
end

if escolher == 1  %Gráfico da malha com a identificação dos nós 
    fill(X,Y,'w')
    for k=1:NTN %Nós
        text(MatrizNOs(k,2),MatrizNOs(k,3),int2str(MatrizNOs(k,1)),'fontsize',8,'color','r'); 
    end
    for k=1:NTE %Elementos
        text((sum(X(:,k)/length(X(:,k))))-4,sum(Y(:,k)/length(Y(:,k))),int2str(k),'fontsize',8,'color','b');  
    end 

elseif escolher == 2 %Gráfico da malha com o mapa de cores
    fill(X,Y,analisar);
    axis([min(MatrizNOs(:,2)) max(MatrizNOs(:,2)) min(MatrizNOs(:,3)) max(MatrizNOs(:,3))]);
	colormap(jet);
	axis off;
    colorbar;
end

end
