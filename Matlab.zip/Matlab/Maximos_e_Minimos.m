
%Determina os valores máximos e mínimos das tensões, tensões de VonMises,
%extensões e deslocamentos

function [TensaoxMax,TensaoxMin,TensaoyMax,TensaoyMin,TensaoxyMax,...
    TensaoxyMin,ExtensaoxMax,ExtensaoxMin,ExtensaoyMax,ExtensaoyMin,ExtensaoxyMax,...
    ExtensaoxyMin,ExtensaozMax,ExtensaozMin,uMax,uMin,vMax,vMin,VonMisesMax,VonMisesMin] = Maximos_e_Minimos(Tensaox,Tensaoy,...
    Tensaoxy,Extensaox,Extensaoy,Extensaoxy,Extensaoz,u,v,VonMises)

%Tensões máximas e mínimas
TensaoxMax = max(Tensaox);
TensaoxMin = min(Tensaox);
TensaoyMax = max(Tensaoy);
TensaoyMin = min(Tensaoy);
TensaoxyMax = max(Tensaoxy);
TensaoxyMin = min(Tensaoxy);

%Extensões máximas e mínimas
ExtensaoxMax = max(Extensaox);
ExtensaoxMin = min(Extensaox);
ExtensaoyMax = max(Extensaoy);
ExtensaoyMin = min(Extensaoy);
ExtensaoxyMax = max(Extensaoxy);
ExtensaoxyMin = min(Extensaoxy);
ExtensaozMax = max(Extensaoz);
ExtensaozMin = min(Extensaoz);

%Tensões Von Mises máxima e mínima
VonMisesMax = max(VonMises(:,2));
VonMisesMin = min(VonMises(:,2));

%Deslocamentos máximos e mínimos
uMax = max(abs(u));
uMin = min(abs(u));
vMax = max(abs(v));
vMin = min(abs(v));

end


