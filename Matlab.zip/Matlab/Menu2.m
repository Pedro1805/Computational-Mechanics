%Cria o menu no qual se escolhe a opção a observar

function varargout = Menu2(varargin)
% MENU2 MATLAB code for Menu2.fig
%      MENU2, by itself, creates a new MENU2 or raises the existing
%      singleton*.
%
%      H = MENU2 returns the handle to a new MENU2 or the handle to
%      the existing singleton*.
%
%      MENU2('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MENU2.M with the given input arguments.
%
%      MENU2('Property','Value',...) creates a new MENU2 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Menu2_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Menu2_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Menu2

% Last Modified by GUIDE v2.5 07-Dec-2022 20:51:21

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Menu2_OpeningFcn, ...
                   'gui_OutputFcn',  @Menu2_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Menu2 is made visible.
function Menu2_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Menu2 (see VARARGIN)

% Choose default command line output for Menu2
handles.output = hObject;

handles.NNOE = evalin('base','NNOE');
handles.NTE = evalin('base','NTE');
handles.NTN = evalin('base','NTN');
handles.MatrizNOs = evalin('base','MatrizNOs');
handles.MatrizConectividades = evalin('base','MatrizConectividades');

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Menu2 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Menu2_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in malhabutton.
function malhabutton_Callback(hObject, eventdata, handles)
% hObject    handle to malhabutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Malha = 1;
Desenhar_Malhas(Malha,handles.NNOE,handles.NTE,handles.NTN,handles.MatrizNOs,handles.MatrizConectividades);

% --- Executes on button press in resultadosbutton.
function resultadosbutton_Callback(hObject, eventdata, handles)
% hObject    handle to resultadosbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
ResultadosDisplay;


% --- Executes on button press in voltarbutton.
function voltarbutton_Callback(hObject, eventdata, handles)
% hObject    handle to voltarbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Menu;
close (Menu2);


% --- Executes on button press in deslocamentobutton.
function deslocamentobutton_Callback(hObject, eventdata, handles)
% hObject    handle to deslocamentobutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Malha = 2;
Desenhar_Malhas(Malha,handles.NNOE,handles.NTE,handles.NTN,handles.MatrizNOs,handles.MatrizConectividades);


% --- Executes on button press in tensaobutton.
function tensaobutton_Callback(hObject, eventdata, handles)
% hObject    handle to tensaobutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Malha = 3;
Desenhar_Malhas(Malha,handles.NNOE,handles.NTE,handles.NTN,handles.MatrizNOs,handles.MatrizConectividades);

% --- Executes on button press in vonmisesbutton.
function vonmisesbutton_Callback(hObject, eventdata, handles)
% hObject    handle to vonmisesbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Malha = 5;
Desenhar_Malhas(Malha,handles.NNOE,handles.NTE,handles.NTN,handles.MatrizNOs,handles.MatrizConectividades);

% --- Executes on button press in extensaobutton.
function extensaobutton_Callback(hObject, eventdata, handles)
% hObject    handle to extensaobutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Malha = 4;
Desenhar_Malhas(Malha,handles.NNOE,handles.NTE,handles.NTN,handles.MatrizNOs,handles.MatrizConectividades);
