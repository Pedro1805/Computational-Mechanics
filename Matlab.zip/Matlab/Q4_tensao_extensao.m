
function [Tensao, Extensao] = Q4_tensao_extensao(x1,y1,x2,y2,x3,y3,x4,y4,C,Delta)

csi = 0;
eta = 0;

[B] = B_Q4(x1,y1,x2,y2,x3,y3,x4,y4,csi,eta);

Extensao = B*Delta;
Tensao = C*Extensao;

end