
function [Tensao, Extensao] = Q8_tensao_extensao(x1,y1,x2,y2,x3,y3,x4,y4,x5,y5,x6,y6,x7,y7,x8,y8,C,Delta)
csi = 0;
eta = 0;

[B] = B_Q8(x1,y1,x2,y2,x3,y3,x4,y4,x5,y5,x6,y6,x7,y7,x8,y8,csi,eta);

Extensao = B*Delta;
Tensao = C*Extensao;

end