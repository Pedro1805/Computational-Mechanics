%Escreve os resultados da simulação

function Solucoes = Resultados(NTE,NTN)

u = evalin('base','u');
v = evalin('base','v');
Tensaox = evalin('base','Tensaox');
Tensaoy = evalin('base','Tensaoy');
Tensaoxy = evalin('base','Tensaoxy');
Extensaox = evalin('base','Extensaox');
Extensaoy = evalin('base','Extensaoy');
Extensaoxy = evalin('base','Extensaoxy');
Extensaoz = evalin('base','Extensaoz');
VonMises = evalin('base','VonMises');

[TensaoxMax,TensaoxMin,TensaoyMax,TensaoyMin,TensaoxyMax,...
    TensaoxyMin,ExtensaoxMax,ExtensaoxMin,ExtensaoyMax,ExtensaoyMin,ExtensaoxyMax,...
    ExtensaoxyMin,ExtensaozMax,ExtensaozMin,uMax,uMin,vMax,vMin,VonMisesMax,VonMisesMin] = Maximos_e_Minimos(Tensaox,Tensaoy,...
    Tensaoxy,Extensaox,Extensaoy,Extensaoxy,Extensaoz,u,v,VonMises)

uMax = evalin('base', 'uMax');
uMin = evalin('base', 'uMin');
vMax = evalin('base', 'vMax');
vMin = evalin('base', 'vMin');
TensaoxMax = evalin('base','TensaoxMax');
TensaoxMin = evalin('base','TensaoxMin');
TensaoyMax = evalin('base','TensaoyMax');
TensaoyMin = evalin('base','TensaoyMin');
TensaoxyMax = evalin('base','TensaoxyMax');
TensaoxyMin = evalin('base','TensaoxyMin');
ExtensaoxMax = evalin('base','ExtensaoxMax');
ExtensaoxMin = evalin('base','ExtensaoxMin');
ExtensaoyMax = evalin('base','ExtensaoyMax');
ExtensaoyMin = evalin('base','ExtensaoyMin');
ExtensaoxyMax = evalin('base','ExtensaoxyMax');
ExtensaoxyMin = evalin('base','ExtensaoxyMin');
ExtensaozMax = evalin('base','ExtensaozMax');
ExtensaozMin = evalin('base','ExtensaozMin');
VonMisesMax = evalin('base','VonMisesMax');
VonMisesMin = evalin('base','VonMisesMin');
E_def = evalin('base','E_def');

if NTN==231
    p0 = sprintf('\nResultados para a simulação da Geometria Simples:\n');
elseif NTN==169
    p0 = sprintf('\nResultados para a simulação da malha Quad4:\n');
elseif NTN==477
    p0 = sprintf('\nResultados para a simulação da malha Quad8:\n');
elseif NTN==115
    p0 = sprintf('\nResultados para a simulação da malha Tri3:\n');
elseif NTN==428
    p0 = sprintf('\nResultados para a simulação da malha Tri6:\n');
end

p1 = sprintf('Número de nós: %d     Número de elementos: %d \r\n\n',NTN,NTE);

p2 = sprintf(['                                             Máximo                 Mínimo\n']);

p3 = sprintf('Deslocamento em x:     %.4f mm      %.6f mm',uMax,uMin);
p4 = sprintf('Deslocamento em y:     %.4f mm      %.6f mm\r\n',vMax,vMin);

p5 = sprintf('Tensão em x:                 %.2f MPa       %.2f MPa',TensaoxMax*(10^-6),TensaoxMin*(10^-6));
p6 = sprintf('Tensão em y:                 %.2f MPa         %.2f MPa',TensaoyMax*(10^-6),TensaoyMin*(10^-6));
p7 = sprintf('Tensão em xy:               %.2f MPa         %.2f MPa',TensaoxyMax*(10^-6),TensaoxyMin*(10^-6));
p8 = sprintf('Von Mises:                     %.2f MPa         %.2f MPa\r\n',VonMisesMax*(10^-6),VonMisesMin*(10^-6));

p9 = sprintf('Extensão em x:                    %.4f               %.4f',ExtensaoxMax,ExtensaoxMin);
p10 = sprintf('Extensão em y:                    %.4f               %.4f',ExtensaoyMax,ExtensaoyMin);
p11 = sprintf('Extensão em z:                    %.4f               %.4f',ExtensaozMax,ExtensaozMin);
p12 = sprintf('Extensão em xy:                  %.4f               %.4f\r\n',ExtensaoxyMax,ExtensaoxyMin);

p13 = sprintf('Energia de deformação elástica: %.2f J',E_def);

Solucoes = strvcat(p0,p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12,p13);

end