

function [Tensao,Extensao] = T3_tensao_extensao(x1,y1,x2,y2,x3,y3,C,Delta)

Ae2 = abs((x2-x1)*(y3-y1)-(y2-y1)*(x3-x1));
Ae = Ae2/2;

d1dx = (y2-y3)/Ae2;
d1dy = (x3-x2)/Ae2;
d2dx = (y3-y1)/Ae2;
d2dy = (x1-x3)/Ae2;
d3dx = (y1-y2)/Ae2;
d3dy = (x2-x1)/Ae2;

B = [d1dx 0 d2dx 0 d3dx 0;0 d1dy 0 d2dy 0 d3dy;d1dy d1dx d2dy d2dx d3dy d3dx];

Extensao = B*Delta;
Tensao = C*Extensao;

end