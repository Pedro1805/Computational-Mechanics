
function [MatrizNOs, MatrizConectividades,u,v,Tensaox,Extensaox,Tensaoy,Extensaoy,Tensaoxy,...
    Extensaoxy,Extensaoz,VonMises,NTE,x,y,E_def,V] = T6(Ficheiro,NNOE)

[NTN,MatrizNOs,NTE,MatrizConectividades,E,...
    V,T,MatrizCondFronteira,MatrizTensFronteira] = LeituraDados(Ficheiro,NNOE);

x = MatrizNOs(:,2);
y = MatrizNOs(:,3);

C = (E/(1-V^2))*[1 V 0;V 1 0;0 0 0.5*(1-V)];

Neq = 2*NTN;
Kg = zeros(Neq,Neq);
fg = zeros(Neq,1);
Qg = zeros(Neq,1);


for i=1:NTE
    no1 = MatrizConectividades(i,4);
    no2 = MatrizConectividades(i,5);
    no3 = MatrizConectividades(i,6);
    no4 = MatrizConectividades(i,7);
    no5 = MatrizConectividades(i,8);
    no6 = MatrizConectividades(i,9);
    
    idof1 = (no1-1)*2+1;
    idof2 = (no2-1)*2+1;
    idof3 = (no3-1)*2+1;
    idof4 = (no4-1)*2+1;
    idof5 = (no5-1)*2+1;
    idof6 = (no6-1)*2+1;
    
    edofs = [idof1 idof1+1 idof2 idof2+1 idof3 idof3+1 idof4 idof4+1 idof5 idof5+1 idof6 idof6+1];

    [Ke, fe] = Ke_T6(x(no1),y(no1),x(no2),y(no2),x(no3),y(no3),x(no4),y(no4),x(no5),y(no5),x(no6),y(no6),C,T);

    Kg(edofs,edofs) = Kg(edofs,edofs)+Ke;
    fg(edofs,1) = fg(edofs,1)+fe;
end

p = 0;
boom = 1.0e+14;

for i=1:size(MatrizCondFronteira,1)
    no1 = MatrizCondFronteira(i,1);
    dof = MatrizCondFronteira(i,2);
    notimport = MatrizCondFronteira(i,3);

    if dof == 1
        idof = (no1-1)*2+1;
        Kg(idof,idof) = boom;
        fg(idof,1) = boom*p;
    else
        idof = (no1-1)*2+2;
        Kg(idof,idof) = boom;
        fg(idof,1) = boom*p;
    end
end

for i=1:size(MatrizTensFronteira,1)
    no1 = MatrizTensFronteira(i,2);
    no2 = MatrizTensFronteira(i,3);
    no3 = MatrizTensFronteira(i,4);
    
    condicoes_naturais_tens_x = MatrizTensFronteira(i,5);
    condicoes_naturais_tens_y = MatrizTensFronteira(i,6);
    
    idof1 = (no1-1)*2+1;
    idof2 = (no2-1)*2+1;
    idof3 = (no3-1)*2+1;
    
    Fronteira_y = [y(no1) y(no2) y(no3)];

    Qg(idof1,1) = Qg(idof1)+condicoes_naturais_tens_x*T*(max(Fronteira_y)-min(Fronteira_y))/6;
    Qg(idof1+1,1) = Qg(idof1+1)+condicoes_naturais_tens_y*T*(max(Fronteira_y)-min(Fronteira_y))/6;
    Qg(idof2,1) = Qg(idof2)+4*condicoes_naturais_tens_x*T*(max(Fronteira_y)-min(Fronteira_y))/6;
    Qg(idof2+1,1) = Qg(idof2+1)+4*condicoes_naturais_tens_y*T*(max(Fronteira_y)-min(Fronteira_y))/6;
    Qg(idof3,1) = Qg(idof3)+condicoes_naturais_tens_x*T*(max(Fronteira_y)-min(Fronteira_y))/6;
    Qg(idof3+1,1) = Qg(idof3+1)+condicoes_naturais_tens_y*T*(max(Fronteira_y)-min(Fronteira_y))/6;
end

Kg = sparse(Kg);
q = Kg\(fg+Qg);
u = q(1:2:Neq,1);
v = q(2:2:Neq,1);

Tensaox = zeros(NTE,1);
Tensaoy = zeros(NTE,1);
Tensaoxy = zeros(NTE,1);
Extensaox = zeros(NTE,1);
Extensaoy = zeros(NTE,1);
Extensaoxy = zeros(NTE,1);
VonMises = zeros(NTE,2);

for i=1:NTE
    no1 = MatrizConectividades(i,4);
    no2 = MatrizConectividades(i,5);
    no3 = MatrizConectividades(i,6);
    no4 = MatrizConectividades(i,7);
    no5 = MatrizConectividades(i,8);
    no6 = MatrizConectividades(i,9);
    
    idof1 = (no1-1)*2+1;
    idof2 = (no2-1)*2+1;
    idof3 = (no3-1)*2+1;
    idof4 = (no4-1)*2+1;
    idof5 = (no5-1)*2+1;
    idof6 = (no6-1)*2+1;
    
    edofs = [idof1 idof1+1 idof2 idof2+1 idof3 idof3+1 idof4 idof4+1 idof5 idof5+1 idof6 idof6+1];
    Delta = q(edofs);

    [Tensao,Extensao] = T6_tensao_extensao(x(no1),y(no1),x(no2),y(no2),x(no3),y(no3),x(no4),y(no4),x(no5),y(no5),x(no6),y(no6),C,Delta);

    Tensaox(i,1) = Tensao(1,1);
    Tensaoy(i,1) = Tensao(2,1);
    Tensaoxy(i,1) = Tensao(3,1);
    Extensaox(i,1) = Extensao(1,1);
    Extensaoy(i,1) = Extensao(2,1);
    Extensaoxy(i,1) = Extensao(3,1);

    I1 = Tensaox(i,1) + Tensaoy(i,1);
    I2 = Tensaox(i,1)*Tensaoy(i,1)-Tensaoxy(i,1)^2;
    VonMises(i,1) = i;
    VonMises(i,2) = sqrt(I1^2-3*I2);
end

Extensaoz = (-V/(1-V))*(Extensaox+Extensaoy);
Extensaoz = Extensaoz';
E_def = 0.5*q'*Kg*q*10^-3;

end






