

function [Tensao, Extensao] = T6_tensao_extensao(x1,y1,x2,y2,x3,y3,x4,y4,x5,y5,x6,y6,C,Delta)

csi = 1/3;
eta = 1/3;

[B] = B_T6(x1,y1,x2,y2,x3,y3,x4,y4,x5,y5,x6,y6,csi,eta);


Extensao = B*Delta;
Tensao = C*Extensao;

end