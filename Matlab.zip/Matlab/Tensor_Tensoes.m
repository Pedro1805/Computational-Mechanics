
%Calcula o tensor das tensões e as tensões principais 

function [TensorTensoes,Tensoes_Principais] = Tensor_Tensoes(Tensaox,Tensaoy,Tensaoxy,NTE)

TensorTensoes = zeros(3*NTE,4);
Tensoes_Principais = zeros(NTE,4);

for i=1:NTE

    %Tensor das tensões
    TensorTensoes(3*i-2,1) = i;
    TensorTensoes(3*i-1,1) = i;
    TensorTensoes(3*i,1) = i;
    
    Tensaoz = zeros(i,1);
    
    TensorTensoes(3*i-2,2) = Tensaox(i);
    TensorTensoes(3*i-1,2) = Tensaoxy(i);
    TensorTensoes(3*i-2,3) = Tensaoxy(i);
    TensorTensoes(3*i-1,3) = Tensaoy(i);
    TensorTensoes(3*i,4) = Tensaoz(i);

    %Tensões principais (círculo de Mohr)
    Centro = (Tensaox+Tensaoy)/2;
    r = sqrt((((Tensaox-Tensaoy)/2).^2)+(Tensaoxy.^2));
    
    Tensoes_Principais(i,1) = i;
    Tensoes_Principais(i,2) = Centro(i)+r(i);
    Tensoes_Principais(i,3) = Centro(i)-r(i);
    Tensoes_Principais(i,4) = Tensaoz(i);
end
end
